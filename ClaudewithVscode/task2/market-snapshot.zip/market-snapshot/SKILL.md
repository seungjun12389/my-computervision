---
name: market-snapshot
description: Yahoo Finance에서 주요 시장 지표(S&P 500, 나스닥, 다우존스, 코스피, 코스닥, 미국채 10년물 금리, 금 가격, 원/달러 환율)의 현재 스냅샷을 조회해 표/JSON/CSV로 정리한다. 사용자가 "마켓 스냅샷", "시장 지표", "지수 현황", "코스피/나스닥 얼마", "금값", "환율", "국채 금리" 등 시황·지표 조회를 요청할 때 사용한다.
---

# Market Snapshot

Yahoo Finance(`yfinance`)에서 주요 시장 지표를 한 번에 조회해 정리한다.

## 조회 대상

| 지표 | 티커 | 단위 |
|---|---|---|
| S&P 500 | `^GSPC` | pt |
| 나스닥 종합 | `^IXIC` | pt |
| 다우존스 산업평균 | `^DJI` | pt |
| 코스피 | `^KS11` | pt |
| 코스닥 | `^KQ11` | pt |
| 미국채 10년물 금리 | `^TNX` | % |
| 금 (COMEX 선물) | `GC=F` | USD/oz |
| 원/달러 환율 | `KRW=X` | KRW |

## 사용 방법

1. 의존성이 없으면 먼저 설치한다 (이미 설치돼 있으면 건너뛴다):

   ```bash
   python -c "import yfinance" 2>/dev/null || python -m pip install -q -r "<skill-dir>/requirements.txt"
   ```

   **반드시 `pip` 대신 `python -m pip`을 쓴다.** 시스템에 파이썬이 여러 개 설치돼 있으면
   `pip`은 스크립트를 실행할 인터프리터가 아닌 다른 파이썬에 설치할 수 있고,
   그러면 설치가 성공해도 `ModuleNotFoundError: No module named 'yfinance'`가 계속 난다.
   `python -m pip`은 항상 그 `python`에 설치하므로 둘이 어긋나지 않는다.
   Windows에서 `py`로 실행한다면 설치도 `py -m pip`으로 해야 한다
   (`py`의 기본 버전과 PATH의 `python`이 다른 버전을 가리키는 경우가 흔하다).

2. 스크립트를 실행한다. 기본은 표 출력이다:

   ```bash
   python "<skill-dir>/scripts/market_indicators.py"
   ```

3. 다른 출력 형식이 필요하면:

   ```bash
   python "<skill-dir>/scripts/market_indicators.py" --json          # JSON (프로그램 처리용)
   python "<skill-dir>/scripts/market_indicators.py" --csv out.csv   # CSV 저장 (Excel용 BOM 포함)
   ```

   사용자가 파일로 저장해달라고 하거나 스프레드시트를 언급하면 `--csv`,
   결과를 다시 가공·계산해야 하면 `--json`, 그 외에는 기본 표 출력을 쓴다.

## 결과 해석 시 주의할 점

- **종가 기준이며 실시간 시세가 아니다.** 최근 2개 영업일 종가로 등락을 계산한다.
- **지표별로 기준일이 다를 수 있다.** 한국장과 미국장은 개장 시간이 다르므로,
  국내 지수는 당일 값이고 미국 지수·국채는 전 영업일 값인 경우가 정상이다.
  사용자에게 보고할 때 각 행의 기준일을 함께 전달한다.
- **미국채 10년물(`^TNX`)은 이미 퍼센트 단위**다. 4.784는 4.784%를 뜻하므로 다시 100을 곱하지 않는다.
- 한 티커가 실패해도 나머지는 정상 출력되고 해당 행에만 "조회 실패"가 표시된다.
  일부만 실패하면 성공한 지표를 보고하고 실패한 항목을 따로 언급한다.
- 네트워크가 차단된 환경에서는 전부 실패한다. 그 경우 조회를 반복하지 말고
  네트워크 접근이 필요하다고 사용자에게 알린다.
- 설치했는데도 `ModuleNotFoundError`가 나면 인터프리터 불일치를 먼저 의심한다.
  `python -c "import sys; print(sys.executable)"`로 실제 실행 중인 파이썬 경로를 확인하고,
  그 경로의 `-m pip install`로 다시 설치한다. VS Code에서는 선택된 인터프리터
  (Ctrl+Shift+P → "Python: Select Interpreter")가 터미널의 `python`과 다를 수 있다.

## 지표 추가하기

`scripts/market_indicators.py`의 `INDICATORS` 리스트에 한 줄을 추가하면 된다.
`Indicator(표시이름, 야후_티커, 단위, decimals=소수점자릿수)` 형식이다. 예:

```python
Indicator("WTI 원유", "CL=F", "USD/bbl"),
Indicator("비트코인", "BTC-USD", "USD", decimals=0),
```

## 사용자에게 보고하기

표를 그대로 붙여넣기보다, 눈에 띄는 움직임(큰 등락, 방향이 엇갈리는 시장)을
한두 문장으로 짚어준 뒤 전체 수치를 제시한다. 조회 시각과 기준일은 반드시 포함한다.
